package controller;

import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import driver.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.UserModel;

import javax.swing.border.Border;

public class LoginController implements Initializable{
	@FXML private TextField username;
	@FXML private PasswordField password;
	@FXML private Button login;
	@FXML private Button register;
	static Stage stage;
	public static String user;
	public static int ID;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		login.setOnAction(e->{
			if(Main.isEmptyOrBlank(username) || Main.isEmptyOrBlank(password)) {
				Main.showAlert("Please Fill all fields", 0);
			}else{
				try {
					UserModel model = new UserModel(username.getText(),password.getText());
					ResultSet resultSet = model.login();
					if(resultSet.next()){
						try{
							user  = resultSet.getString("username");
							ID = resultSet.getInt("id");
							FXMLLoader loader = new FXMLLoader();
							loader.setLocation(getClass().getResource("../view/root.fxml"));
							BorderPane borderPane = loader.load();
							stage = new Stage();
							stage.setScene(new Scene(borderPane));
							stage.setTitle("Quiz Application");
							stage.show();
							Main.primaryStage.getScene().getWindow().hide();
						}catch (Exception exception){
							exception.printStackTrace();
						}
					} else
						Main.showAlert("Username or password incorrect", 0);
				}catch (Exception ee){
					ee.printStackTrace();
				}
			}
		});
		register.setOnAction(actionEvent -> {
			try{
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation(getClass().getResource("../view/addStudent.fxml"));
				BorderPane borderPane = loader.load();
				Stage stage = new Stage();
				stage.setScene(new Scene(borderPane));
				stage.setTitle("Register");
				stage.show();
			}catch (Exception e){
				e.printStackTrace();
			}
		});
	}
}
