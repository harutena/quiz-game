package controller;

import database.Database;
import driver.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import javax.xml.crypto.Data;
import java.net.URL;
import java.security.spec.ECField;
import java.util.ResourceBundle;

public class AdviceController implements Initializable {
    @FXML private ComboBox<String> courses;
    @FXML private Button retake;
    @FXML private Button advice;

    public static String sub;
    public static Stage stage;
    public static int p;
    public static int t;
    public static String n;

    private ObservableList<String> coursesList;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        coursesList = FXCollections.observableArrayList();
        Database db = new Database();
        try{
            db.preStatement = db.connection.prepareStatement("SELECT * FROM marks");
            db.result = db.preStatement.executeQuery();
            while (db.result.next()){
                coursesList.add(db.result.getString("subject"));
            }
            courses.setItems(coursesList);
        }catch (Exception e){
            e.printStackTrace();
        }
        retake.setOnAction(action->{
            int userID = LoginController.ID;
            String subject = courses.getValue();
            try{
                db.preStatement = db.connection.prepareStatement("SELECT * FROM marks WHERE " +
                        "subject ='"+subject+"' AND user_id ='"+userID+"'");
                db.result = db.preStatement.executeQuery();
                if(db.result.next()){
                    int obtainMarks = db.result.getInt("obtain");
                    int totalMarks = db.result.getInt("total_marks");
                    double percentage = (((double) obtainMarks / (double)totalMarks) * 100);
                    System.out.println(obtainMarks+" "+totalMarks+" "+percentage);
                    if(percentage < 60){
                        sub = subject;
                        p = totalMarks/10;
                        t = 20;
                        FXMLLoader loader = new FXMLLoader();
                        loader.setLocation(getClass().getResource("../view/retake.fxml"));
                        BorderPane pane = loader.load();
                        stage = new Stage();
                        stage.setScene(new Scene(pane));
                        stage.setTitle("Quiz");
                        stage.show();
                        stage.setOnCloseRequest(e->{
                            stage.close();
                        });
                    }else{
                        Main.showAlert("You dont have to give retake",1);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        advice.setOnAction(action->{
            int userID = LoginController.ID;
            String subject = courses.getValue();
            try{
                db.preStatement = db.connection.prepareStatement("SELECT * FROM marks WHERE " +
                        "subject ='"+subject+"' AND user_id ='"+userID+"'");
                db.result = db.preStatement.executeQuery();
                if(db.result.next()){
                    int obtainMarks = db.result.getInt("obtain");
                    int totalMarks = db.result.getInt("total_marks");
                    double percentage = (((double) obtainMarks / (double)totalMarks) * 100);
                    System.out.println(obtainMarks+" "+totalMarks+" "+percentage);
                    if(percentage < 60){
                        if(courses.getValue().equalsIgnoreCase("Computer Science"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://www.physicsandmathstutor.com/\ncomputer-science-revision/a-level-ocr",0);
                        else if(courses.getValue().equalsIgnoreCase("Math"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://www.khanacademy.org/math",0);
                        else if(courses.getValue().equalsIgnoreCase("History"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://studywise.co.uk/a-level-revision/history",0);
                        else if(courses.getValue().equalsIgnoreCase("Psychology"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://www.simplypsychology.org/a-level-psychology.html",0);
                        else if(courses.getValue().equalsIgnoreCase("Physics"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://pakmcqs.com/category/physics-mcqs",0);
                        else if(courses.getValue().equalsIgnoreCase("Biology"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://byjus.com/biology/biology-mcqs/",0);
                        else if(courses.getValue().equalsIgnoreCase("Chemistry"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://sheir.org/edu/mcqs/chemistry/",0);
                        else if(courses.getValue().equalsIgnoreCase("Geography"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://www.gktoday.in/quizbase/world-geography",0);
                        else if(courses.getValue().equalsIgnoreCase("Business"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://www.examveda.com/commerce/\npractice-mcq-question-on-\nbusiness-and-commerce/",0);
                        else if(courses.getValue().equalsIgnoreCase("Economics"))
                            Main.showAlert("You have to give retake\n" +
                                    "https://global.oup.com/uk/orc/busecon/\neconomics/king/01student/mcqs/",0);
                    }else{
                        Main.showAlert("You dont have to give retake",1);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        });
    }
}
