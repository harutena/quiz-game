package controller;

import database.Database;
import driver.Main;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.QuestionModel;

import java.net.URL;
import java.util.ResourceBundle;

public class AddQuestionController implements Initializable {
    @FXML
    private ComboBox<String> subjects;
    @FXML
    private TextField question;
    @FXML
    private TextField optionA;
    @FXML
    private TextField optionB;
    @FXML
    private TextField optionC;
    @FXML
    private TextField optionD;
    @FXML
    private TextField correct;
    @FXML
    private TextField reason;
    @FXML
    private TextField revision;
    @FXML
    private TextField name;
    @FXML
    private Button add;
    private ObservableList<String> category;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        category = FXCollections.observableArrayList();
        category.addAll("Computer Science", "Math", "Physics", "Biology", "Chemistry", "History",
                "Geography", "Psychology", "Business", "Economics");
        subjects.setItems(category);
        add.setOnAction(actionEvent -> {
            if (Main.isEmptyOrBlank(question) || Main.isEmptyOrBlank(optionA) || Main.isEmptyOrBlank(optionB) ||
                    Main.isEmptyOrBlank(optionC) || Main.isEmptyOrBlank(optionD) || Main.isEmptyOrBlank(correct)
                    || Main.isEmptyOrBlank(reason)) {
                Main.showAlert("Please Fill all Fields", 0);
            } else {
                try {
                    if (checkEqual(optionA.getText(), optionB.getText()) || checkEqual(optionA.getText(),
                            optionC.getText()) || checkEqual(optionA.getText(), optionD.getText()) ||
                            checkEqual(optionB.getText(), optionA.getText()) || checkEqual(optionB.getText(),
                            optionC.getText()) || checkEqual(optionB.getText(), optionD.getText()) ||
                            checkEqual(optionC.getText(), optionA.getText()) || checkEqual(optionC.getText(),
                            optionB.getText()) || checkEqual(optionC.getText(), optionD.getText()) ||
                            checkEqual(optionD.getText(), optionA.getText()) || checkEqual(optionD.getText(),
                            optionB.getText()) || checkEqual(optionD.getText(), optionC.getText())) {
                        Main.showAlert("Option can't be same", 0);
                    } else if ((!(correct.getText().equalsIgnoreCase(optionA.getText()))) &&
                            (!(correct.getText().equalsIgnoreCase(optionB.getText()))) &&
                            (!(correct.getText().equalsIgnoreCase(optionC.getText()))) &&
                            (!(correct.getText().equalsIgnoreCase(optionD.getText())))) {
                        Main.showAlert("Correct Answer not exists in the Options", 0);
                    } else {
                        QuestionModel model = new QuestionModel(question.getText(), optionA.getText(), optionB.getText(),
                                optionC.getText(), optionD.getText(), correct.getText(),
                                subjects.getValue(), reason.getText(), revision.getText(), name.getText());
                        if (model.addQuestion()) {
                            Main.showAlert("Question Added", 1);
                            question.setText(null);
                            optionA.setText(null);
                            optionB.setText(null);
                            optionC.setText(null);
                            optionD.setText(null);
                            correct.setText(null);
                            reason.setText(null);
                            subjects.setItems(category);
                        } else {
                            Main.showAlert("Something went wrong", 0);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private boolean checkEqual(String str1, String str2) {
        return (str1.equalsIgnoreCase(str2));
    }
}
