package controller;

import database.Database;
import driver.Main;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import model.QuestionModel;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicInteger;

public class QuestionController implements Initializable {
    @FXML private Label questionNo;
    @FXML private Label timer;
    @FXML private Label question;
    @FXML private Label name;
    @FXML private RadioButton optionA;
    @FXML private RadioButton optionB;
    @FXML private RadioButton optionC;
    @FXML private RadioButton optionD;
    private ToggleGroup group;
    @FXML private Button submit;
    ArrayList<QuestionModel> list = new ArrayList<>();
    private static final Integer STARTTIME = Integer.parseInt(QuizController.t);
    private Integer timeSeconds = STARTTIME;
    public Timeline time;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        group = new ToggleGroup();
        optionA.setToggleGroup(group);
        optionB.setToggleGroup(group);
        optionC.setToggleGroup(group);
        optionD.setToggleGroup(group);
        name.setText(QuizController.n);
        try{
            Database db = new Database();
            db.preStatement = db.connection.prepareStatement("SELECT * FROM questions WHERE subject='"
                    +QuizController.sub+"' AND name='"+QuizController.n+"'");
            db.result = db.preStatement.executeQuery();
            while (db.result.next()){
                QuestionModel model = new
                        QuestionModel(db.result.getString("question"),db.result.getString("option_A"),
                        db.result.getString("option_B"),db.result.getString("option_C"),
                        db.result.getString("option_D"),db.result.getString("correct"),
                        db.result.getString("subject"),db.result.getString("reason"),
                        db.result.getString("revision"),db.result.getString("name"));
                list.add(model);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        if (list.size() <= 0){
            Main.showAlert("Questions not found!",0);
        }else{
            var ref = new Object() {
                int count = 0;
            };
            Collections.shuffle(list);
            Timeline timeline = new Timeline();
            AtomicInteger marks = new AtomicInteger();
            int total = Integer.parseInt(QuizController.p) * list.size();
            firstTimer(timeline);
            questionNo.setText("Question: "+ ref.count+1);
            nextQuestion(list.get(ref.count).getQuestions(),list.get(ref.count).getOptionA(),list.get(ref.count).getOptionB(),
                    list.get(ref.count).getOptionC(),list.get(ref.count).getOptionD());

            submit.setOnAction(actionEvent -> {
                timeline.stop();
                if (optionA.isSelected() && optionA.getText().equalsIgnoreCase(list.get(ref.count).getCorrect())){
                    marks.addAndGet(Integer.parseInt(QuizController.p));
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("CONGRATULATIONS");
                    success.setHeaderText("CONGRATULATIONS\n"+marks+"/"+total);
                    success.show();
                    optionA.setSelected(false);
                    optionB.setSelected(false);
                    optionC.setSelected(false);
                    optionD.setSelected(false);
                }else if (optionB.isSelected() && optionB.getText().equalsIgnoreCase(list.get(ref.count).getCorrect())){
                    marks.addAndGet(Integer.parseInt(QuizController.p));
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("CONGRATULATIONS");
                    success.setHeaderText("CONGRATULATIONS\n"+marks+"/"+total);
                    success.show();
                    optionA.setSelected(false);
                    optionB.setSelected(false);
                    optionC.setSelected(false);
                    optionD.setSelected(false);
                } else if (optionC.isSelected() && optionC.getText().equalsIgnoreCase(list.get(ref.count).getCorrect())){
                    marks.addAndGet(Integer.parseInt(QuizController.p));
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("CONGRATULATIONS");
                    success.setHeaderText("CONGRATULATIONS\n"+marks+"/"+total);
                    success.show();
                    optionA.setSelected(false);
                    optionB.setSelected(false);
                    optionC.setSelected(false);
                    optionD.setSelected(false);
                }else if (optionD.isSelected() && optionD.getText().equalsIgnoreCase(list.get(ref.count).getCorrect())){
                    marks.addAndGet(Integer.parseInt(QuizController.p));
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("CONGRATULATIONS");
                    success.setHeaderText("CONGRATULATIONS\n"+marks+"/"+total);
                    success.show();
                    optionA.setSelected(false);
                    optionB.setSelected(false);
                    optionC.setSelected(false);
                    optionD.setSelected(false);
                }else{
                    Alert success = new Alert(Alert.AlertType.ERROR);
                    success.setTitle("Bad Luck");
                    success.setHeaderText(list.get(ref.count).getReason()+"\n"+marks+"/"+total);
                    success.show();
                    optionA.setSelected(false);
                    optionB.setSelected(false);
                    optionC.setSelected(false);
                    optionD.setSelected(false);
                }
                ref.count += 1;
                if(list.size() > ref.count) {
                    startTimer();
                    questionNo.setText("Question: " + ref.count);
                    nextQuestion(list.get(ref.count).getQuestions(), list.get(ref.count).getOptionA(), list.get(ref.count).getOptionB(),
                            list.get(ref.count).getOptionC(), list.get(ref.count).getOptionD());
                }else if (list.size() == ref.count){
                    QuizController.stage.getScene().getWindow().hide();
                    timeline.stop();
                    if(((marks.get()/total) *100) >= 60)
                        Main.showAlert("Your marks are Less than 60%\n " +
                                "follow this link for revision\n"+list.get(ref.count).getRevision(),0);
                    storeMarks(total,marks.get());
                }
            });
        }
    }
    private void storeMarks(int marks,int obtain){
        try{
            Database db = new Database();
            db.preStatement = db.connection.prepareStatement("INSERT INTO marks(user_id,subject,obtain,total_marks)" +
                    "VALUES(?,?,?,?)");
            db.preStatement.setInt(1,LoginController.ID);
            db.preStatement.setString(2,QuizController.sub);
            db.preStatement.setInt(3,obtain);
            db.preStatement.setInt(4,marks);
            db.preStatement.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void nextQuestion(String q,String a,String b,String c,String d){
        question.setText(q);
        optionA.setText(a);
        optionB.setText(b);
        optionC.setText(c);
        optionD.setText(d);
    }
    private void firstTimer(Timeline timeline){
        timeSeconds = STARTTIME;
        timer.setText(timeSeconds.toString());
        cycleCount(timeline);
    }

    private void cycleCount(Timeline timeline) {
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.seconds(1),
                        event -> {
                            timeSeconds--;
                            timer.setText(
                                    timeSeconds.toString());
                            if (timeSeconds <= 0) {
                                timeline.stop();
                            }
                        }));
        timeline.playFromStart();
    }

    private void startTimer(){
        if (time != null) {
            time.stop();
        }
        timeSeconds = STARTTIME;
        timer.setText(timeSeconds.toString());
        time = new Timeline();
        cycleCount(time);
    }
}
