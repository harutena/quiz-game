package controller;

import database.Database;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.net.URL;
import java.util.ResourceBundle;

public class StatisticsController implements Initializable {
    @FXML private BarChart<String,Number> graph;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try{
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
            xAxis.setLabel("Subject");
            yAxis.setLabel("Marks");
            Database db = new Database();
            db.preStatement = db.connection.prepareStatement("SELECT * FROM marks WHERE user_id='"+LoginController.ID+"'");
            db.result = db.preStatement.executeQuery();
            XYChart.Series series = new XYChart.Series();
            while (db.result.next()){
                series.setName(db.result.getString("subject"));
                series.getData().add(new XYChart.Data<>(db.result.getString("subject"),
                        Integer.parseInt(db.result.getString("obtain"))));
            }
            graph.getData().add(series);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
