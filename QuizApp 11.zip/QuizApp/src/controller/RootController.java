package controller;

import driver.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;

import java.net.URL;
import java.util.ResourceBundle;

public class RootController implements Initializable {
    @FXML private MenuItem addQuestions;
    @FXML private MenuItem quiz;
    @FXML private MenuItem close;
    @FXML private MenuItem addStudent;
    @FXML private MenuItem graph;
    @FXML private MenuItem advice;
    @FXML private MenuItem leaderBoard;
    @FXML private BorderPane center;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        close.setOnAction(actionEvent -> {
            LoginController.stage.getScene().getWindow().hide();
            try{
                Main.showLogin();
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        addQuestions.setOnAction(actionEvent -> {
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/addQuestions.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        quiz.setOnAction(actionEvent -> {
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/quiz.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        addStudent.setOnAction(actionEvent -> {
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/addStudent.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        graph.setOnAction(actionEvent -> {
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/statistics.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        leaderBoard.setOnAction(actionEvent->{
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/leaderBoard.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        advice.setOnAction(actionEvent->{
            try{
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/advice.fxml"));
                BorderPane borderPane = loader.load();
                center.setCenter(borderPane);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
    }
}
