package controller;

import database.Database;
import driver.Main;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.QuestionModel;

import java.net.URL;
import java.util.ResourceBundle;

public class QuizController implements Initializable {
    @FXML private ComboBox<String> subject;
    @FXML private ComboBox<String> points;
    @FXML private ComboBox<String> time;
    @FXML private ComboBox<String> name;
    @FXML private Button start;

    public static Stage stage;
    public static String sub;
    public static String p;
    public static String t;
    public static String n;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> categories = FXCollections.observableArrayList();
        ObservableList<String> marks = FXCollections.observableArrayList();
        ObservableList<String> limit = FXCollections.observableArrayList();
        ObservableList<String> names = FXCollections.observableArrayList();
        categories.addAll("Computer Science","Math","Physics","Biology","Chemistry","History",
                "Geography","psychology","Business","economics");
        marks.addAll("2","5");
        limit.addAll("10","20","30","40","50","60");
        subject.setItems(categories);
        points.setItems(marks);
        time.setItems(limit);
        subject.valueProperty().addListener((observableValue, s, t1) -> {
            try {
                names.removeAll();
                name.getItems().clear();
                Database db = new Database();
                db.preStatement = db.connection.prepareStatement("SELECT * FROM questions WHERE subject='"+t1+"'");
                db.result = db.preStatement.executeQuery();
                names.removeAll();
                name.getItems().removeAll();
                while (db.result.next()){
                    if(!(db.result.getString("name").isEmpty()||db.result.getString("name").isBlank()))
                        names.add(db.result.getString("name"));
                }
                name.setItems(names);
            }catch (Exception e){
                e.printStackTrace();
            }
        });
        start.setOnAction(actionEvent -> {
            try{
                sub = subject.getValue();
                p = points.getValue();
                t = time.getValue();
                n = name.getValue();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../view/question.fxml"));
                BorderPane pane = loader.load();
                stage = new Stage();
                stage.setScene(new Scene(pane));
                stage.setTitle("Quiz");
                stage.show();
                stage.setOnCloseRequest(e->{
                    stage.close();
                });
            }catch (Exception e){
                e.printStackTrace();
            }
        });
    }

}
