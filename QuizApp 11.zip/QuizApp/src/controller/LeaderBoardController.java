package controller;

import database.Database;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.LeaderBoard;
import model.LeaderBoardModel;

import java.net.URL;
import java.util.*;
public class LeaderBoardController implements Initializable {
    @FXML private TableView<LeaderBoardModel> tableView;
    @FXML private TableColumn<LeaderBoardModel,String> col_Rank;
    @FXML private TableColumn<LeaderBoardModel,String> col_User;
    @FXML private TableColumn<LeaderBoardModel,String> col_Score;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<LeaderBoardModel> datalist = FXCollections.observableArrayList();
        try{
            Database db = new Database();
            db.preStatement = db.connection.prepareStatement("SELECT * FROM users");
            db.result = db.preStatement.executeQuery();
            ArrayList<LeaderBoard> leader = new ArrayList<>();
            while (db.result.next()){
                String username = db.result.getString("username");
                ArrayList<Integer> data = getSingleData(db.result.getInt("id"));
                leader.add(new LeaderBoard(username,data.get(1),data.get(0)));
            }
            leader.sort((o1, o2) -> o2.getPercentage() - o1.getPercentage());

            for (int i = 0; i < leader.size(); ++i){
                LeaderBoardModel model = new LeaderBoardModel();
                model.setRank(String.valueOf(i+1));
                model.setUser(leader.get(i).getUsername());
                model.setScore(leader.get(i).getMarks()+"/"+leader.get(i).getObtain());
                datalist.add(model);
            }
            this.col_Rank.setCellValueFactory(new PropertyValueFactory<>("rank"));
            this.col_User.setCellValueFactory(new PropertyValueFactory<>("user"));
            this.col_Score.setCellValueFactory(new PropertyValueFactory<>("score"));
            tableView.setItems(datalist);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private ArrayList<Integer> getSingleData(int id){
        try{
            ArrayList<Integer> data = new ArrayList<>();
            Database db = new Database();
            db.preStatement = db.connection.prepareStatement("SELECT SUM(obtain)AS obtain," +
                            "SUM(total_marks)as total_marks FROM marks WHERE user_id="+id);
            db.result = db.preStatement.executeQuery();
            int totalMarksGained = 0;
            int totalMarks = 0;
            while (db.result.next()){
                totalMarksGained += db.result.getInt("obtain");
                totalMarks += db.result.getInt("total_marks");
            }
            data.add(totalMarksGained);
            data.add(totalMarks);
            return data;
        }catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
