package controller;

import database.Database;
import driver.Main;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import model.UserModel;

import javax.xml.crypto.Data;
import java.net.URL;
import java.util.ResourceBundle;

public class AddStudentController implements Initializable {
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private Button add;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        add.setOnAction(actionEvent -> {
            if (Main.isEmptyOrBlank(username) || Main.isEmptyOrBlank(password)) {
                Main.showAlert("Please Enter ALl details", 0);
            } else {
                try {
                    Database db = new Database();
                    db.preStatement = db.connection.prepareStatement("SELECT * FROM users WHERE username ='" +
                            username.getText() + "'");
                    db.result = db.preStatement.executeQuery();
                    if (db.result.next()) {
                        Main.showAlert("User already exists", 0);
                    } else {
                        UserModel model = new UserModel(username.getText(), password.getText());
                        if (model.signUp()) {
                            Main.showAlert("Student Add", 1);
                        } else {
                            Main.showAlert("Something went Wrong!", 0);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
