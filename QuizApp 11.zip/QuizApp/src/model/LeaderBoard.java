package model;

public class LeaderBoard {
    private String username;
    private int obtain;
    private int marks;

    public LeaderBoard(String name,int obtain, int marks) {
        this.username = name;
        this.obtain = obtain;
        this.marks = marks;
    }

    public int getPercentage() {
        if (marks == 0)
            return 0;
        return (obtain/marks)*100;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getObtain() {
        return obtain;
    }

    public void setObtain(int obtain) {
        this.obtain = obtain;
    }

    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }
}
