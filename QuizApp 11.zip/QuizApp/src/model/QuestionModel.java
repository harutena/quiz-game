package model;

import database.Database;

public class QuestionModel {
    private String questions;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String correct;
    private String subject;
    private String reason;
    private String revision;
    private String name;

    public QuestionModel(String questions, String optionA, 
                         String optionB, String optionC, String optionD, String correct,
                         String subject,String reason,String revision,String name) {
        this.questions = questions;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correct = correct;
        this.subject = subject;
        this.reason = reason;
        this.revision = revision;
        this.name = name;
    }
    public boolean addQuestion(){
        try {
            Database db = new Database();
            db.preStatement =db.connection.prepareStatement("INSERT INTO questions(question,option_A,option_B," +
                    "option_C,option_D,correct,subject,reason,revision,name)VALUES(?,?,?,?,?,?,?,?,?,?)");
            db.preStatement.setString(1,questions);
            db.preStatement.setString(2,optionA);
            db.preStatement.setString(3,optionB);
            db.preStatement.setString(4,optionC);
            db.preStatement.setString(5,optionD);
            db.preStatement.setString(6,correct);
            db.preStatement.setString(7,subject);
            db.preStatement.setString(8,reason);
            db.preStatement.setString(9,revision);
            db.preStatement.setString(10,name);
            db.preStatement.executeUpdate();
            return true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }

    public String getOptionA() {
        return optionA;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct;
    }
}
