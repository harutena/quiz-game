package model;

import database.Database;

import java.sql.ResultSet;

public class UserModel {
	private int id;
	private String username;
	private String password;
	
	public UserModel(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public ResultSet login() {
		try {
			Database db = new Database();
			db.preStatement = db.connection.prepareStatement("SELECT * FROM users WHERE username='"+
			username+"' AND password='"+password+"'");
			db.result = db.preStatement.executeQuery();
			return db.result;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean signUp(){
		try{
			Database db = new Database();
			db.preStatement = db.connection.prepareStatement("INSERT INTO users(username,password)VALUES(?,?)");
			db.preStatement.setString(1,username);
			db.preStatement.setString(2,password);
			db.preStatement.executeUpdate();
			return true;
		}catch (Exception e){
			e.printStackTrace();
		}
		return false;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

}
