package driver;
	
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
	public static Stage primaryStage;
	@Override
	public void start(Stage primaryStage) throws IOException {
		 Main.primaryStage = primaryStage;
		 showLogin();
	}
	public static void showLogin() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("../view/login.fxml"));
		BorderPane borderPane = loader.load();
		Main.primaryStage.setScene(new Scene(borderPane));
		Main.primaryStage.setTitle("Login");
		Main.primaryStage.show();
	}
	public static void showAlert(String msg, int i) {
		Alert alert;
		if(i == 0) {
			alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("ERROR");
		}else {
			alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setTitle("Information");
		}
		alert.setHeaderText(msg);
		alert.show();
	}
	public static boolean isEmptyOrBlank(TextField tf) {
		return tf.getText().isEmpty() || tf.getText().isBlank();
	}
	public static void main(String[] args) {
		launch(args);
	}
}
